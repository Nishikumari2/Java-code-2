/*
 * InSilico Solutions And Services 
 * www.insilicoss.com
 */
package com.insilicoss.sparc.container;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author admin
 */
public class RunningProperty { 

  public int cviRunngPropOnrD; 
  public String cvsRunngPropActv, cvsRunngPropOnr, cvsRunngPropIdx; 
  public LocalDate cvdRunngPropFrom; 
  public LocalDate cvdRunngPropTo; 
  public BigDecimal cvnRunngPropVal; 
  public int cviRunngPropD; 

  public RunningProperty(String pvsRunngPropActv, String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx, LocalDate pvdRunngPropFrom, 
                         LocalDate pvdRunngPropTo, BigDecimal pvnRunngPropVal, int pviRunngPropD){ 
    cvsRunngPropActv = pvsRunngPropActv; 
    cvsRunngPropOnr  = pvsRunngPropOnr; 
    cviRunngPropOnrD = pviRunngPropOnrD; 
    cvsRunngPropIdx  = pvsRunngPropIdx; 
    cvdRunngPropFrom = pvdRunngPropFrom; 
    cvdRunngPropTo   = pvdRunngPropTo; 
    cvnRunngPropVal  = pvnRunngPropVal; 
    cviRunngPropD    = pviRunngPropD; 
  } 

  public boolean isActive(){ 
    return cvsRunngPropActv != null && "1".equals(cvsRunngPropActv); 
  }
} 
