/*
 * InSilico Solutions And Services 
 * www.insilicoss.com
 */
package com.insilicoss.sparc.modal.payRev;

import com.insilicoss.App;
import com.insilicoss.database.DBManager;
import com.insilicoss.eventManager.OperationResponse;
import com.insilicoss.exception.PresentableException;
import com.insilicoss.exception.SystemException;
import com.insilicoss.sparc.container.RunningProperty;
import com.insilicoss.util.Util;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class RunningPropertyModal {

  DBManager cvoDBManager;

  public RunningPropertyModal(DBManager pvoDBManager) {
    cvoDBManager = pvoDBManager;
  }

  public BigDecimal getRunningPropertyValue(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx, LocalDate pvdRunngPropFor) throws SQLException {
    return getRunningPropertyValue(pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx, pvdRunngPropFor, null);
  }

  public BigDecimal getRunningPropertyValue(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx,
          LocalDate pvdRunngPropFor, BigDecimal pvdDfltValue) throws SQLException {
    cvoDBManager.addContextParam("rvsRunngPropOnr", pvsRunngPropOnr);
    cvoDBManager.addContextParam("rviRunngPropOnrD", pviRunngPropOnrD);
    cvoDBManager.addContextParam("rvsRunngPropIdx", pvsRunngPropIdx);
    cvoDBManager.addContextParam("rvdRunngPropAsOn", pvdRunngPropFor);
    ResultSet lvoRs = cvoDBManager.selectResultSet("RunningProperty/sarRunngPropAsOn");
    if (lvoRs.next()) {
      if (lvoRs.next()) {
        throw new SystemException("Data consistency error. Multiple RunningPropertyValue found for Owner:" + pvsRunngPropOnr
                + "; OwnerD:" + pviRunngPropOnrD
                + "; Idx:" + pvsRunngPropIdx
                + "; As on:" + pvdRunngPropFor);
      }
      lvoRs.first();
      return lvoRs.getBigDecimal("dvnRunngPropVal");
    } else {
      return pvdDfltValue;
    }
  }

  public List<RunningProperty> getRunningPropertyForIdx(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx) throws SQLException {
    cvoDBManager.addContextParam("rvsRunngPropOnr", pvsRunngPropOnr);
    cvoDBManager.addContextParam("rviRunngPropOnrD", pviRunngPropOnrD);
    cvoDBManager.addContextParam("rvsRunngPropIdx", pvsRunngPropIdx);
    ResultSet lvoRs = cvoDBManager.selectResultSet("RunningProperty/sarRunngPropForIdx");
    return buildRunningPropList(lvoRs);
  }

  public List<RunningProperty> getRunningPropertyForRange(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx,
          LocalDate pvdRunngPropFrom, LocalDate pvdRunngPropTo) throws SQLException {
    cvoDBManager.addContextParam("rvsRunngPropOnr", pvsRunngPropOnr);
    cvoDBManager.addContextParam("rviRunngPropOnrD", pviRunngPropOnrD);
    cvoDBManager.addContextParam("rvsRunngPropIdx", pvsRunngPropIdx);
    cvoDBManager.addContextParam("rvdRunngPropFrom", pvdRunngPropFrom);
    cvoDBManager.addContextParam("rvdRunngPropTo", pvdRunngPropTo);
    ResultSet lvoRs = cvoDBManager.selectResultSet("RunningProperty/sarRunngPropForDateRange");
    return buildRunningPropList(lvoRs);
  }

  public List<RunningProperty> getRunningPropertyFrom(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx,
          LocalDate pvdRunngPropFrom) throws SQLException {
    cvoDBManager.addContextParam("rvsRunngPropOnr", pvsRunngPropOnr);
    cvoDBManager.addContextParam("rviRunngPropOnrD", pviRunngPropOnrD);
    cvoDBManager.addContextParam("rvsRunngPropIdx", pvsRunngPropIdx);
    cvoDBManager.addContextParam("rvdRunngPropFrom", pvdRunngPropFrom);
    ResultSet lvoRs = cvoDBManager.selectResultSet("RunningProperty/sarRunngPropFrom");
    return buildRunningPropList(lvoRs);
  }

  private List<RunningProperty> buildRunningPropList(ResultSet lvoRs) throws SQLException {
    RunningProperty lvoRunningProperty;
    List<RunningProperty> lvoRunningPropertyList = new ArrayList<>();
    while (lvoRs.next()) {
      lvoRunningProperty = new RunningProperty("1",
              lvoRs.getString("dvsRunngPropOnr"),
              lvoRs.getInt("dviRunngPropOnrD"),
              lvoRs.getString("dvsRunngPropIdx"),
              lvoRs.getDate("dvdRunngPropFrom").toLocalDate(),
              lvoRs.getDate("dvdRunngPropTo").toLocalDate(),
              lvoRs.getBigDecimal("dvnRunngPropVal"),
              lvoRs.getInt("dviRunngPropD"));
      lvoRunningPropertyList.add(lvoRunningProperty);
    }
    return lvoRunningPropertyList;
  }

  public OperationResponse removeRunningProperty(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx,
          LocalDate pvdRunngPropAsOn, LocalDate pvdValidateFrom, LocalDate pvdValidateTo, boolean pvbValidateOrder) throws SQLException {
    List<RunningProperty> lvoRunningPropertys = getRunningPropertyForIdx(pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx);
    
    if (lvoRunningPropertys.isEmpty()) {
      return new OperationResponse(false, "No entry found.");
    }

    if (pvbValidateOrder && lvoRunningPropertys.size() == 1) {
      return new OperationResponse(false, "Can't remove entry as alteast one entry need to be maintained.");
    }

    if(pvbValidateOrder) { 
      RunningProperty lvoRunningProperty, lvoAdjstRunningProperty;
      for (int index = 0; index < lvoRunningPropertys.size(); index++) {
        lvoRunningProperty = lvoRunningPropertys.get(index);
        
        if (lvoRunningProperty.isActive() && Util.isBetween(pvdRunngPropAsOn, lvoRunningProperty.cvdRunngPropFrom, lvoRunningProperty.cvdRunngPropTo)) {
          _deactivateRunningProperty(lvoRunningProperty);
          
          if (index == 0) { //removing first entry i.e: 1. Remove First 2. Update second from as pvdValidateFrom; 
            lvoAdjstRunningProperty = lvoRunningPropertys.get(index + 1);
            lvoAdjstRunningProperty.cvdRunngPropFrom = pvdValidateFrom;
          } else if (index == lvoRunningPropertys.size() - 1) { //removing last entry i.e: 1. Remove Last 2. Update last -1 to as pvdValidateTo; 
            lvoAdjstRunningProperty = lvoRunningPropertys.get(index - 1);
            lvoAdjstRunningProperty.cvdRunngPropTo = pvdValidateTo;
          } else { //removing middle entry i.e: 1.Remove middle entry 2.Update middle -1 entry to as middle + 1 entry from -1 day; 
            lvoAdjstRunningProperty = lvoRunningPropertys.get(index - 1);
            lvoAdjstRunningProperty.cvdRunngPropTo = lvoRunningPropertys.get(index + 1).cvdRunngPropFrom.minusDays(1);
          }
          
          _updateRunningProperty(lvoAdjstRunningProperty);
          
          if (!validateOrder(lvoRunningPropertys, pvdValidateFrom, pvdValidateTo, pvbValidateOrder)) { 
            return new OperationResponse(false, "Invalid order of running values. Contact support.");
          }
          
          OperationResponse or = new OperationResponse(true, "");
          or.setAttribute("RunningPropertys", lvoRunningPropertys);
          
          return or;
        }
      } 
    } 
    else { 
      for (RunningProperty lvoRunningProperty : lvoRunningPropertys) { 
        if(lvoRunningProperty.cvdRunngPropFrom.compareTo(pvdRunngPropAsOn) == 0){ 
          _deactivateRunningProperty(lvoRunningProperty); 
          return OperationResponse.OK; 
        } 
        else if(Util.isBetween(pvdRunngPropAsOn, lvoRunningProperty.cvdRunngPropFrom, lvoRunningProperty.cvdRunngPropTo)){ 
          lvoRunningProperty.cvdRunngPropTo = pvdRunngPropAsOn.minusDays(1); 
          _updateRunningProperty(lvoRunningProperty); 
          return OperationResponse.OK; 
        } 
      } 
    } 
    return new OperationResponse(false, "Invalid property found as on " + pvdRunngPropAsOn.format(App.DATE_FORMATTER)); 
  } 

  public OperationResponse updateRunningProperty(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx,
                                                 LocalDate pvdRunngPropAsOn, BigDecimal pvnRunngPropVal, 
                                                 LocalDate pvdValidateFrom, LocalDate pvdValidateTo, int pviRunngPropD, boolean pvbValidateOrder) throws SQLException {
    LocalDate lvdRunngPropCloseDate = pvdRunngPropAsOn.minusDays(1);
    List<RunningProperty> lvoRunningPropertys = getRunningPropertyForIdx(pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx);
    RunningProperty lvoRunningProperty, lvoBeforeRunnedProperty, lvoAfterRunnedProperty;

    if (lvoRunningPropertys.isEmpty()) {
      return new OperationResponse(true, "Not able to update as no revision found with the specified date :: " + pvdRunngPropAsOn);
    } else {
      for (int index = 0; index < lvoRunningPropertys.size(); index++) {
        lvoRunningProperty = lvoRunningPropertys.get(index);

        if (lvoRunningProperty.cviRunngPropD == pviRunngPropD) { 
          if (index != 0) { 
            lvoBeforeRunnedProperty = lvoRunningPropertys.get(index - 1); 
            if(Util.isBeforeOrOn(pvdRunngPropAsOn, lvoBeforeRunnedProperty.cvdRunngPropFrom)){ 
              throw new PresentableException("Can't erase revision dated " + lvoBeforeRunnedProperty.cvdRunngPropFrom.format(App.DATE_FORMATTER) + 
                                              ". Try after removing revision dated " + lvoBeforeRunnedProperty.cvdRunngPropFrom.format(App.DATE_FORMATTER) + "."); 
            } 
            if(index+1 != lvoRunningPropertys.size()) { 
              lvoAfterRunnedProperty  = lvoRunningPropertys.get(index + 1); 
              if(Util.isAfterOrOn(pvdRunngPropAsOn, lvoAfterRunnedProperty.cvdRunngPropFrom)){ 
                throw new PresentableException("Can't erase revision dated " + lvoAfterRunnedProperty.cvdRunngPropFrom.format(App.DATE_FORMATTER) + 
                                                ". Try after removing revision dated " + lvoAfterRunnedProperty.cvdRunngPropFrom.format(App.DATE_FORMATTER) + "."); 
              } 
            } 

            lvoBeforeRunnedProperty.cvdRunngPropTo = lvdRunngPropCloseDate; 
            _updateRunningProperty(lvoBeforeRunnedProperty); 
          } 
          lvoRunningProperty.cvdRunngPropFrom = pvdRunngPropAsOn; 
          lvoRunningProperty.cvnRunngPropVal  = pvnRunngPropVal; 
          _updateRunningProperty(lvoRunningProperty); 
        } 
      } 

      if (validateOrder(lvoRunningPropertys, pvdValidateFrom, pvdValidateTo, pvbValidateOrder)) { 
        OperationResponse or = new OperationResponse(true, "");
        or.setAttribute("RunningPropertys", lvoRunningPropertys);
        return or;
      } else {
        return new OperationResponse(false, "Date should be the joining date of employee.");
      }
    }
  }

  public OperationResponse addRunningProperty(String pvsRunngPropOnr, int pviRunngPropOnrD, String pvsRunngPropIdx,
          LocalDate pvdRunngPropAsOn, BigDecimal pvnRunngPropVal, LocalDate pvdValidateFrom, LocalDate pvdValidateTo, boolean pvbValidateOrder) throws SQLException {
    List<RunningProperty> lvoRunningPropertys = getRunningPropertyForIdx(pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx);
    RunningProperty lvoNewRunningProperty = null, lvoRunningProperty, lvoFirstRunningProperty, lvoLastRunningProperty;
    int lvoRunningPropertysLength, lviInsertIndex = -1;
    boolean added = false; 

    if (lvoRunningPropertys.isEmpty()) {
      lvoRunningProperty = new RunningProperty("1", pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx,
              pvdRunngPropAsOn, pvdValidateTo, pvnRunngPropVal, -1);
      _addRunningProperty(lvoRunningProperty);
      lvoRunningPropertys.add(lvoRunningProperty); 
      added = true; 
    } else { 
      lvoRunningPropertysLength = lvoRunningPropertys.size(); 
      lvoFirstRunningProperty = lvoRunningPropertys.get(0); 
      lvoLastRunningProperty = lvoRunningPropertys.get(lvoRunningPropertysLength - 1); 
      if (Util.isBefore(pvdRunngPropAsOn, lvoFirstRunningProperty.cvdRunngPropFrom)) { 
        lvoNewRunningProperty = new RunningProperty("1", pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx, 
                pvdRunngPropAsOn, lvoFirstRunningProperty.cvdRunngPropFrom.minusDays(1), pvnRunngPropVal, -1); 
        lvoRunningPropertys.add(0, lvoNewRunningProperty); 
        _addRunningProperty(lvoNewRunningProperty); 
        added = true; 
      } 
      else if (Util.isAfter(pvdRunngPropAsOn, lvoLastRunningProperty.cvdRunngPropTo)) { 
        lvoNewRunningProperty = new RunningProperty("1", pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx, 
                pvdRunngPropAsOn, pvdValidateTo, pvnRunngPropVal, -1); 
        lvoRunningPropertys.add(0, lvoNewRunningProperty); 
        _addRunningProperty(lvoNewRunningProperty); 
        added = true; 
      } 
      else { 
        for (RunningProperty lvoRunningProperty1 : lvoRunningPropertys) { 
          if(lvoRunningProperty1.cvdRunngPropFrom.equals(pvdRunngPropAsOn)) { 
            lvoRunningProperty1.cvnRunngPropVal = pvnRunngPropVal; 
            _updateRunningProperty(lvoRunningProperty1); 
            added = true; 
            break; 
          } 
          else if(Util.isBetween(pvdRunngPropAsOn, lvoRunningProperty1.cvdRunngPropFrom, lvoRunningProperty1.cvdRunngPropTo)){ 
            lvoNewRunningProperty = new RunningProperty("1", pvsRunngPropOnr, pviRunngPropOnrD, pvsRunngPropIdx, 
                                    pvdRunngPropAsOn, lvoRunningProperty1.cvdRunngPropTo, pvnRunngPropVal, -1); 
            lviInsertIndex = lvoRunningPropertys.indexOf(lvoRunningProperty1); 
            _addRunningProperty(lvoNewRunningProperty); 

            lvoRunningProperty1.cvdRunngPropTo = pvdRunngPropAsOn.minusDays(1); 
            _updateRunningProperty(lvoRunningProperty1);
            break; 
          } 
        } 
        if(lvoNewRunningProperty != null && lviInsertIndex != -1){ 
          lvoRunningPropertys.add(lviInsertIndex+1, lvoNewRunningProperty); 
          added = true; 
        } 
      } 
    } 
    if(!added){ 
      return new OperationResponse(false, "Can't add as on " + pvsRunngPropIdx + " as on " + pvdRunngPropAsOn); 
    }
    if (validateOrder(lvoRunningPropertys, pvdValidateFrom, pvdValidateTo, pvbValidateOrder)) { 
      OperationResponse or = new OperationResponse(true, "");
      or.setAttribute("RunningPropertys", lvoRunningPropertys);
      return or;
    } else {
      return new OperationResponse(false, "Date should be the joining date of employee Property : " + pvsRunngPropIdx);
    }
  }

  private boolean validateOrder(List<RunningProperty> pvoRunningPropertys, LocalDate pvdRunngPropFrom, LocalDate pvdRunngPropTo, boolean pvbValidateOrder) { 
    RunningProperty lvoRunningPropertyLast = null;

    if(pvbValidateOrder) { // No Overlaping and In Chronology order
      int actvIndex = -1;
      for (RunningProperty lvoRunningProperty : pvoRunningPropertys) {
        if (!lvoRunningProperty.isActive()) {
          continue;
        }

        actvIndex++;
        if (actvIndex == 0) {
          if (lvoRunningProperty.cvdRunngPropFrom.isAfter(pvdRunngPropFrom)) {
            return false;
          }
        }

        if (actvIndex != 0) {
          if (!lvoRunningPropertyLast.cvdRunngPropTo.plusDays(1).isEqual(lvoRunningProperty.cvdRunngPropFrom)) {
            return false;
          }
        }

        lvoRunningPropertyLast = lvoRunningProperty;
      }

      if (lvoRunningPropertyLast != null) {
        if (lvoRunningPropertyLast.cvdRunngPropTo.isBefore(pvdRunngPropTo)) { 
          return false;
        }
      } else {
        return false;
      }
      return true;
    } 
    else { // No Overlaping only; 
      RunningProperty lvoRunningPropertyPrvs = null; 
      for (RunningProperty lvoRunningProperty : pvoRunningPropertys) { 
        if(lvoRunningPropertyPrvs == null){
          lvoRunningPropertyPrvs = lvoRunningProperty; 
          continue; 
        } 

        if(Util.isOverlaping(lvoRunningPropertyPrvs.cvdRunngPropFrom, lvoRunningPropertyPrvs.cvdRunngPropTo, 
                          lvoRunningProperty.cvdRunngPropFrom, lvoRunningProperty.cvdRunngPropTo)){ 
          return false; 
        } 
      } 
      return true; 
    } 
  } 

  public void _addRunningProperty(RunningProperty pvoRunningProperty) {
    cvoDBManager.addContextParam("rvsRunngPropOnr", pvoRunningProperty.cvsRunngPropOnr);
    cvoDBManager.addContextParam("rviRunngPropOnrD", pvoRunningProperty.cviRunngPropOnrD);
    cvoDBManager.addContextParam("rvsRunngPropIdx", pvoRunningProperty.cvsRunngPropIdx);
    cvoDBManager.addContextParam("rvdRunngPropFrom", pvoRunningProperty.cvdRunngPropFrom);
    cvoDBManager.addContextParam("rvdRunngPropTo", pvoRunningProperty.cvdRunngPropTo);
    cvoDBManager.addContextParam("rvnRunngPropVal", pvoRunningProperty.cvnRunngPropVal);
    cvoDBManager.addContextParam("rviRunngPropD", pvoRunningProperty.cviRunngPropD);
    cvoDBManager.update("RunningProperty/i1rRunngProp");
  }

  public void _updateRunningProperty(RunningProperty pvoRunningProperty) {
    cvoDBManager.addContextParam("rvdRunngPropFrom", pvoRunningProperty.cvdRunngPropFrom);
    cvoDBManager.addContextParam("rvdRunngPropTo", pvoRunningProperty.cvdRunngPropTo);
    cvoDBManager.addContextParam("rvnRunngPropVal", pvoRunningProperty.cvnRunngPropVal);
    cvoDBManager.addContextParam("rviRunngPropD", pvoRunningProperty.cviRunngPropD);
    cvoDBManager.update("RunningProperty/u1rUpdateRunngProp");
  }

  public void _deactivateRunningProperty(RunningProperty pvoRunningProperty) {
    pvoRunningProperty.cvsRunngPropActv = "0";
    cvoDBManager.addContextParam("rviRunngPropD", pvoRunningProperty.cviRunngPropD);
    cvoDBManager.update("RunningProperty/u1rDactvtRunngProp");
  }
}
